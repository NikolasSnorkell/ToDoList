import Resizable from './resizable';

export { Resizable };

export default Resizable;
