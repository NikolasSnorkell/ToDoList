import Sensor from './sensor';
import MouseSensor from './mouse-sensor';

export { Sensor, MouseSensor };

export default {
	Sensor,
	MouseSensor
};
