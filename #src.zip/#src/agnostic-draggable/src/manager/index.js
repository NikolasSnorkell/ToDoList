import DragDropManager from './manager';

export { DragDropManager };

export default DragDropManager;
