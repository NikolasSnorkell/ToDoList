import Droppable from './droppable';

export { Droppable };

export default Droppable;
